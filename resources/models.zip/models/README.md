This folder contains the seven generated trigram models, one for each chord.
