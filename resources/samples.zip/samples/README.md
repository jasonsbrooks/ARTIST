This folder contains a sample of generated MIDI files.
