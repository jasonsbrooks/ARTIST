This folder contains eight (8) separate dumped PostgreSQL databases.

- Each database has separate songs as described in the documentation.
- All songs have been analyzed using the `analyze.chords` module.
